#include <bits/stdc++.h>
using namespace std;

mt19937 myrand(time(NULL));

int main() {
    // 生成一个 [1,1000] 的随机数并且输出
//    cout << 1ll* myrand() % (int) 1e15 + 1 << endl;
    return 0;
}774088797
